[
    {
    nom: "Tu no ets de Vilanova si no …",
    descripcio: " …",
    imatge: "http/xxx",
    tags:["social"],
    },

    {
    nom: "Antics alumnes Escola XXXX",
    descripcio: " …",
    imatge: "http/xxx",
    tags: ["social, records"],
    },

    {
    nom: "Vilanova imatges d'ahir i avui",
    descripcio: " …",
    imatge: "http/xxx",
    tags: ["records"],
    },

    {
    nom: "Anem a caminar",
    descripcio: " …",
    imatge: "http/xxx",
    tags:["esport, salut"],
    },
    
    {
    nom: "Club Esportiu Ribes",
    descripcio: " …",
    imatge: "http/xxx",
    tags:["esport", "aventura"],
    },     
]