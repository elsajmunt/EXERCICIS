
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Agencia</title> <!-- NOU PIS -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    <body>
        <?php include "header.php"?>
        <div class="container mt-3">
            <h2>Alta Nou Pis</h2>
            <form action="../includes/noupis-inc.php" method="post"> 
                <div class="mb-3">
                    <label for="identificador">Identificador Pis:</label>
                    <input type="text" class="form-control" id="identificador"  name="identificador">
                </div>
                <div class="mb-3">
                    <label for="tipus">Tipus:</label>
                    <select class="form-control" id="tipus" name="tipus">
                        <option value="0">Escull una opció</option>
                        <option value="VENTA">Venta</option>
                        <option value="LLOGUER">Lloguer</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="numHabitacions">Num. habitacions:</label>
                    <input type="number" class="form-control" id="numHabitacions" name="numHabitacions">
                </div>
                <div class="mb-3">
                    <label for="numLavabos">Num. Lavabos:</label>
                    <input type="numLavabos" class="form-control" id="numLavabos" name="numLavabos">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
            <span>
                <?php if (isset($_GET['error'])){
                echo $_GET['error'];
                }
                ?>
            </span>
        </div>
    </body>
</html>