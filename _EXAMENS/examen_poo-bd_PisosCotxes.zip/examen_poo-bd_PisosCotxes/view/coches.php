<!DOCTYPE html> <!-- COCHES -->
<html lang="en">
    <head>
        <title>Agencia</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    <body>
        <?php include "header.php"?>
        <div class="container mt-3">
            <h2>Coches</h2>
            <div class="float-end"><a href="../includes/generatePdf.php"><button class="btn btn-primary">Generate PDF</button></a> </div>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Marca</th>
                    <th>Matrícula</th>
                    <th>Color</th>
                    <th>Identificador</th>
                </tr>
                <tr> Coches seleccionats:
                <?php
                include ("../includes/coches-inc.php");
                ?>
                    <?php if($coches!=0){?>
                        <?php foreach($coches as $coche): ?>
                            <tr>
                            <td><?= $coche["marca"] ?></td>
                            <td><?= $coche["matricula"] ?></td>
                            <td><?= $coche["color"] ?></td>
                            <td><?= $coche["identificador"] ?></td>
                        </tr>
                        <?php endforeach ?>
                    <?php }?>
                </tr>
            </thead>
            </table>
        </div>
    </body>
</html>