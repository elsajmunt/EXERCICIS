<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Logo</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav  me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="pisos.php">Pisos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="noupis.php">Alta Pis</a>
                </li>
            </ul>
            <div class="d-flex">
                <ul class="navbar-nav  me-auto">

                <?php /*
                $usuari = $_SESSION['username']; // Mostra usuari << Arreglar
                echo "<div>Hola $usuari :)</div>"; */
                ?> 
                    <li class="nav-item">
                        <a href="reservapis.php">Reserva Pis</a>&nbsp;&nbsp;&nbsp;&nbsp;
                    </li>
                    <li class="nav-item">
                        <a href="pisos.php">Veure Pisos Reservats</a>&nbsp;&nbsp;&nbsp;&nbsp;
                    </li>

                    <li class="nav-item">
                        <a href="../index.php">Login</a>&nbsp;&nbsp;
                    </li>
                    <li class="nav-item">
                        <a href="../includes/logout.php">Logout</a>&nbsp;&nbsp;&nbsp;
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>