
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Agencia</title> <!-- NOU COCHE -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    <body>
        <?php include "header.php"?>
        <div class="container mt-3">
            <h2>Alta Nou Coche</h2>
            <form action="../includes/noucoche-inc.php" method="post"> 
            <div class="mb-3"> <!-- MARCA -->
                    <label for="marca">Marca Coche:</label>
                    <input type="text" class="form-control" id="marca"  name="marca">
            </div>
            <div class="mb-3"> <!-- MATRÍCULA -->
                    <label for="matricula">Matrícula:</label>
                    <input type="text" class="form-control" id="matricula"  name="matricula">
            </div>
            <div class="mb-3"> <!-- COLOR -->
                    <label for="color">Color:</label>
                    <input type="text" class="form-control" id="color"  name="color">
            </div>
            <div class="mb-3"> <!-- IDENTIFICADOR -->
                    <label for="identificador">Identificador Coche:</label>
                    <input type="text" class="form-control" id="identificador"  name="identificador">
            </div>            
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
        </div>

    </body>
</html>