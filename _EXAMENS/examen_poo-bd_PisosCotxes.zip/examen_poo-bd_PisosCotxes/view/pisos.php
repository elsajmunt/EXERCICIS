
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Agencia</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    <body>
        <?php include "header.php"?>
        <div class="container mt-3">
            <h2>Pisos</h2>
            <div class="float-end"><a href="../includes/generatePdf.php"><button class="btn btn-primary">Generate PDF</button></a> </div>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Identifador pis</th>
                    <th>Tipus</th>
                    <th>Num. habitacions</th>
                    <th>Num. Lavabos</th>
                </tr>
                <tr> Pisos seleccionats:
                <?php
                include ("../includes/pisos-inc.php");
                ?>
                    <?php if($pisos!=0){?>
                        <?php foreach($pisos as $pis): ?> <!-- LLISTA PISOS -->
                            <tr>
                            <td><?= $pis["identificador"] ?></td>
                            <td><?= $pis["tipus"] ?></td>
                            <td><?= $pis["numhabitacions"] ?></td>
                            <td><?= $pis["numlavabos"] ?></td>
                        </tr>
                        <?php endforeach ?>
                    <?php }?>
                </tr>
            </thead>
            </table>
        </div>
    </body>
</html>