<?php 
// COCHE
class cocheContr extends Coche{ // Classe Coche està a la carpeta Model 
    private $marca;
    private $matricula;
    private $color;
    private $identificador;

    public function __construct($marca=null, $matricula=null, $color=null, $identificador=null){
        $this->marca = $marca;
        $this->matricula = $matricula;
        $this->color = $color;
        $this->identificador = $identificador;
    }

    /* Setters and getters */ 

    private function setmarca($marca){ // MARCA COCHE // private function Canviar a public function??!!
        $this->marca = $marca;
    }
    private function getmarca(){
        return $this->marca;
    }

    private function setmatricula($matricula){ //MATRÍCULA
         $this->matricula = $matricula;
    }
    private function getmatricula(){
        return $this->matricula;
    }
    
    private function setcolor($color){ // COLOR
        $this->color = $color;
    }
    private function getcolor(){
        return $this->color;
    }
   
    private function setidentificador($identificador){ // IDENTIFICADOR 
        $this->identificador = $identificador;
    }
    private function getidentificador(){
        return $this->identificador;
    }
    /*** */

   // MÈTODES/FUNCIONS: 

   public function nouCoche(){  // FUNCIÓ AFEGIR UN NOU COCHE
         if($this->emptyInput() == false ){ 
             header("Location: ../view/noucoche.php?ERROR=ElsCampsSonObligatoris!");               
             exit();
         }
         
         //insertCoche to DB 
         if($this->insertCoche($this->marca,$this->matricula, $this->color, $this->identificador) /*== true*/){ // Funció està a Model
             header("Location: ../view/noucoche.php?error=FailedStmt"); // $error = true; Resultat Error!
         }
     }    

 // FUNCIONS PER VALIDAR FORMULARI NOU COCHE: 
     private function emptyInput(){ // INPUT BUIT
         $result = true;
         if(empty($this->marca) || empty($this->matricula) || empty($this->color) || empty($this->identificador)){
             $result = false;
         }
         return $result;
     }

     public function mostraCoches(){  // FUNCIÓ MOSTRAR  << acabar! -------------------
       // Posar Condicions...
            
        //selectCoches to DB 
        $resultat = $this->selectCoches() ;
        return $resultat;
    }    

private function reservaCoche(){  // FUNCIÓ RESERVAR  << acabar -------------------
        if($this->emptyInput() == false){ 
            header("Location: ../view/noucoche.php?ERROR=ElsCampsSonObligatoris!");               
            exit();
        }        
    } 
} 