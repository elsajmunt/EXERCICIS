<?php 

class pisContr extends Pis{ // Classe Pis està a la carpeta Model
    private $identificador; 
    private $tipus;
    private $numhabitacions;
    private $numlavabos;

    public function __construct($identificador=null, $tipus=null, $numhabitacions=null, $numlavabos=null){
        $this->identificador = $identificador;
        $this->tipus = $tipus;
        $this->numhabitacions = $numhabitacions;
        $this->numlavabos = $numlavabos;
    }

    /* Setters and getters */ 

    private function setidentificador($identificador){ // IDENTIFICADOR PIS
        $this->identificador = $identificador;
    }
    private function getidentificador(){
        return $this->identificador;
    }

    private function settipus($tipus){ // TIPUS PIS
         $this->tipus = $tipus;
    }
    private function gettipus(){
        return $this->tipus;
    }
    
    private function setnumhabitacions($numhabitacions){ // NÚM HABITACIONS 
        $this->numhabitacions = $numhabitacions;
    }
    private function getnumhabitacions(){
        return $this->numhabitacions;
    }
   
    private function setnumlavabos($numlavabos){ // NÚM LAVABOS 
        $this->numlavabos = $numlavabos;
    }
    private function getnumlavabos(){
        return $this->numlavabos;
    }

    /*** */

    public function nouPis(){  // FUNCIÓ AFEGIR UN NOU PIS -------------------
            if($this->emptyInput() == false ){ 
                header("Location: ../view/noupis.php?ERROR=ElsCampsSonObligatoris!");               
                exit();
            }
            
            //insertPis to DB 
            if($this->insertPis($this->identificador,$this->tipus, $this->numhabitacions, $this->numlavabos) /*== true*/){ // Funció insertPis està a Model/pis.php
                header("Location: ../view/noupis.php?error=FailedStmt"); // $error = true; Resultat Error!
            }
        }    

    // FUNCIONS PER VALIDAR FORMULARI NOU PIS:  <<< acabar!
        private function emptyInput(){ // Si INPUT BUIT
            $result = true;
            if(empty($this->tipus) || empty($this->numhabitacions) || empty($this->numlavabos) || empty($this->identificador)){
                $result = false;
            }
            return $result;
        }
      
        public function mostraPisos(){  // FUNCIÓ MOSTRAR PIS/PISOS? << acabar! -------------------
            
                // Posar Condicions...
                    
                //selectPisos to DB 
                $resultat = $this->selectPisos() ;               
                return $resultat;
            }    

        private function reservaPis(){  // FUNCIÓ RESERVAR PIS << acabar -------------------
                if($this->emptyInput() == false){ 
                    header("Location: ../view/reservapis.php?ERROR=ElsCampsSonObligatoris!");               
                    exit();
                }
                
                //SELECT Pis de DB 
              // if($this->selecttPis($this->tipus, $this->numhabitacions, $this->numlavabos) /*== true*/)//{ // Funció insertPis està a Model/pis.php
                    //header("Location: ../view/noupis.php?error=FailedStmt"); // $error = true; Resultat Error!
//}
            }    
            
} 

