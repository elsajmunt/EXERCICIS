<?php 

// RESERVA Està malament ? Eliminar!

class reservaContr extends Reserva{ // Classe Reserva a la carpeta Model << afegir 
    private $id;
    private $data; 
    private $id_pis; // Foreign Key
    private $id_user; // Foreign Key


    private function __construct($id, $data){
        $this->id = $id;
        $this->data = $data;
        $this->id_pis = $id_pis;
        $this->id_user = $id_user;
    }

    /* Setters and getters */ 

    private function setid($id){ // ID RESERVA
        $this->id = $id;
    }
    private function getid(){
        return $this->id;
    }

    private function setdata($id){ // DATA RESERVA
        $this->data = $data;
    }
    private function getdata(){
        return $this->data;
    }

    private function setidpis($id_pis){ // ID PIS RESERVA // Foreign Key (?)
        $this->id_pis = $id_pis;
    }
    private function getidpis(){
        return $this->id_pis;
    }

    private function setiduser($id_user){ // ID USER RESERVA // Foreign Key (?)
        $this->id_user = $id_user;
    }
    private function getiduser(){
        return $this->id_user;
    }

    /*** */
    
    // MÈTODES/FUNCIONS PENDENTS ..... <<
            
} 

