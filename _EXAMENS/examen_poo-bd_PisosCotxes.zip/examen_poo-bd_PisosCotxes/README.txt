DADES PIS:
pisos
	id 
	tipus
	numhabitacions
	numlavabos

--
Identificador Pis:
Tipus:
	Venta/LLoguer/...
Num. habitacions:
Num. Lavabos: 

---------------
DADES USUARI: 
`users` 
  `users_id` 
  `users_uid` 
  `users_pwd` 
  `users_email` 

-----------------
DADES RESERVES: 
reserves
	id
	data

-----------------
DADES COCHE: 
coches
	marca
	matricula
	color
	identificador
