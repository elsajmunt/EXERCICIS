<?php // MOSTRAR COCHES

          //instanciar las classes
    require "../model/connection.php";
    require "../model/coche.php"; // Depèn de coche.php - BD
    require "../controler/CocheContr.php"; // Depèn de CocheContr.php - Mètodes/Funcions

    $cocheContr = new CocheContr(); // Classe del Controler
    $coches = $cocheContr->mostraCoches(); // mostraCoches és una Funció de la Classe cochesContr
