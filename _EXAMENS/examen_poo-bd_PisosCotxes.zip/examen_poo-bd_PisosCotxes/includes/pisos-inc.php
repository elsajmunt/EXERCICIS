<?php // MOSTRAR PISOS



          //instanciar las classes
    require "../model/connection.php";
    require "../model/pis.php"; // Depèn de pis.php - BD
    require "../controler/PisContr.php"; // Depèn de PisContr.php - Funcions

    $pisContr = new PisContr(); // Classe del Controler
    $pisos = $pisContr->mostraPisos(); // mostraPisos és una Funció de la Classe pisContr

