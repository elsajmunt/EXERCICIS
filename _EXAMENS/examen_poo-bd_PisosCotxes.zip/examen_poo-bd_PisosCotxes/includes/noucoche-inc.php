<?php // ALTA NOU COCHE...

if($_SERVER["REQUEST_METHOD"] == "POST"){ //

    // recoger datos del formulario
    $marca  = $_POST["marca"]; // Ha de ser mateix Nom que a Formulari noucoche.php
    $matricula  = $_POST["matricula"]; 
    $color  = $_POST["color"]; 
    $identificador  = $_POST["identificador"];

    //instanciar las classes
    require "../model/connection.php";
    require "../model/coche.php"; // Depèn de coche.php - BD <<<< Pendent crear/Adaptar.....
    require "../controler/cocheContr.php"; // Depèn de cocheContr.php - Funcions

    $noucoche = new cocheContr($marca, $matricula, $color, $identificador); // Classe del Controler
    $noucoche->nouCoche(); // nouCoche és una Funció de la Classe cocheContr  <<<<<<

    //Volver a la pagina inicial (si està tot bé!)
    header("Location: ../view/coches.php"); // RESULTAT OK <<<< Pendent crear Pàgina....!!
}