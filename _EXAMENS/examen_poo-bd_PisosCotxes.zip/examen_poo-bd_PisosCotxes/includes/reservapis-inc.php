<?php // RESERVAR PIS... // No funciona

if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["send"])){

    // recoger datos del formulario
      $id_pis = $_POST["id_pis"]; // Foreign Key (?)
      $id_user = $_POST["id_user"]; // Foreign Key (?)
  //  $tipus = $_POST["tipus"];

    //instanciar las classes
    require "../model/connection.php";
    require "../model/Reserva.php"; 
    require "../controler/reservaContr.php"; 

    $noupis = new reservaContr($id_pis, $id_user); // Classe del Controler
    $noupis->reservaPis(); // << Crear Funció a la Classe pisContr

    //Volver a la pagina inicial (si està tot bé!)
    header("Location: ../view/reservapis.php"); // RESULTAT OK
} 