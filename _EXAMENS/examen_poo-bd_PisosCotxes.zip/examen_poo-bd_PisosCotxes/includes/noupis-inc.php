<?php // CREAR NOU PIS...

if($_SERVER["REQUEST_METHOD"] == "POST"){ //

    // recoger datos del formulario
    $identificador = $_POST["identificador"]; // id=Identificador (No és el id Incrementable de la BD!)
    $tipus = $_POST["tipus"]; // Ha de ser mateix Nom que a Formulari noupis.php!!!
    $numhabitacions = $_POST["numHabitacions"];
    $numlavabos = $_POST["numLavabos"];

    //instanciar las classes
    require "../model/connection.php";
    require "../model/pis.php"; // Depèn de pis.php - BD
    require "../controler/PisContr.php"; // Depèn de PisContr.php - Funcions

    $noupis = new PisContr($identificador, $tipus, $numhabitacions, $numlavabos); // Classe del Controler
    $noupis->nouPis(); // nouPis és una Funció de la Classe pisContr

    //Volver a la pagina inicial (si està tot bé!)
    header("Location: ../view/pisos.php"); // RESULTAT OK
}