<?php
class Pis extends Connection{ // CONEXIONS A LA BASE DE DADES:

    protected function insertPis($identificador, $tipus, $numhabitacions, $numlavabos){ // AFEGIR DADES - INSERT (id=> identificador) <<<< CANVIAR
        $error = false;
        $stmt = $this->connect()->prepare("INSERT INTO pisos (identificador, tipus, numhabitacions, numlavabos) VALUES (?,?,?,?)");

        if(!$stmt->execute(array($identificador, $tipus, $numhabitacions, $numlavabos))){
            $error = true;
        }
        $stmt = null;
        return $error;
    }

    protected function selectPisos(){ // MOSTRAR DADES -SELECT
        $stmt = $this->connect()->prepare("SELECT * FROM pisos"); //?..
        if(!$stmt->execute()){
            $stmt = null;
            header("Location: .../view/pisos.php?error=stmtfailed"); // Error
            exit();
        }
        $result = 0; 
        if($stmt->rowCount()>0){ // Si hi ha contingut a la Taula...
            $result = $stmt->fetchAll(); // recull totes les dades de la taula pisos
        }

        return $result; // retorna o el resultat de la base de dades o 0 en cas que no hi hagi dades.
    }
}