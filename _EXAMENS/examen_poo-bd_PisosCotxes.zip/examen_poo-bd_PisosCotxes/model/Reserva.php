<?php
class Reserva extends Connection{ // CONEXIONS A LA BASE DE DADES: ......

    protected function insertReserva($id, $data, $id_pis, $id_user){ // AFEGIR DADES de la Reserva - INSERT + JOINS... <<< ACABAR/Arreglar..!!
        $error = false;
        $stmt = $this->connect()->prepare("INSERT INTO reserves (id, 'data', id_pis, id_user) VALUES (NULL,NOW(),?,?)");

        if(!$stmt->execute(array($id, $data, $id_pis, $id_user))){
            $error = true;
        }
        $stmt = null;
        return $error;
    }
    /* Penent arreglar...
    protected function selectReserva($tipus, $identificador){ // MOSTRAR DADES de la Reserva -SELECT
        $stmt = $this->connect()->prepare("SELECT tipus FROM reserves WHERE tipus = ? OR identificador = ?;"); //?..
        if(!$stmt->execute(array($tipus, $identificador))){
            $stmt = null;
            header("Location: .../view/noupis.php?error=stmtfailed"); // Error
            exit();
        }
        $resultCheck = false;
        if($stmt->rowCount()>0){
            $resultCheck = true;
        }
        return $resultCheck;
    } */
}