<?php

class Connection { // CONEXIÓ A LA BD

    protected function connect(){
        try {
        //    $con = new PDO('mysql:host=localhost;dbname=prova', 'prova','prova'); // Canviar a l'entrega Examen!! :)
              $con = new PDO('mysql:host=localhost;dbname=prova', 'root','');

            return $con;
        } catch (PDOException $e) {
            return "Error!: ". $e->getMessage()."<br>";
        }
    }
}