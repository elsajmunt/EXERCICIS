<?php
class Coche extends Connection{ // CONEXIONS A LA BASE DE DADES:

// COCHE 

    protected function insertCoche($marca, $matricula, $color, $identificador){ // AFEGIR DADES - INSERT
        $error = false;
        $stmt = $this->connect()->prepare("INSERT INTO coches (marca, matricula, color, identificador) VALUES (?,?,?,?)");

        if(!$stmt->execute(array($marca, $matricula, $color, $identificador))){
            $error = true;
        }
        $stmt = null;
        return $error;
    }

    protected function selectCoches(){ // MOSTRAR DADES -SELECT
        $stmt = $this->connect()->prepare("SELECT * FROM coches"); // Mostrar tot el contingut de la Taula
        if(!$stmt->execute()){
            $stmt = null;
            header("Location: .../view/coches.php?error=stmtfailed"); // Error
            exit();
        }
        $result = 0; 
        if($stmt->rowCount()>0){
            $result = $stmt->fetchAll(); // recull totes les dades de la Taula coches.
        }
        return $result; // retorna o el resultat de la base de dades o 0 en cas que no hi hagi dades.
    } 
}
