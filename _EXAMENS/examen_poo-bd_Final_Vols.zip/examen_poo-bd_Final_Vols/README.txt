AVIONS:

(BD):
aviones
	IdAvion
	Matricula
	Fabricante
	Modelo
	Capacidad
	AutonomiaVuelo

----
id_avio
matricula
fabricante
modelo
capacidad

-------------------------------
                include ("../includes/avions-inc.php");
                ?>
                    <?php if($avions!=0){?>
                        <?php foreach($avions as $avio): ?> <!-- LLISTA AVIONS -->
                            <tr>
                            <td><?= $avio["id_avio"] ?></td> 
                            <td><?= $avio["matricula"] ?></td>
                            <td><?= $avio["fabricante"] ?></td>
                            <td><?= $avio["modelo"] ?></td>
                            <td><?= $avio["capacidad"] ?></td>