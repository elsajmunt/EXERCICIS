
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Vuelos/Alta Nou Vol</title> <!-- NOU VOL -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    <body>
        <?php include "header.php"?>
        <div class="container mt-3">
            <h2>Alta Nou Vol</h2>
            <form action="../includes/nouvol-inc.php" method="post"> 

                <div class="mb-3">
                    <label for="IdVuelo">Identificador Vol:</label> 
                    <input type="text" class="form-control" id="IdVuelo"  name="IdVuelo">
                </div>

                <div class="mb-3">
                    <label for="Fecha">Data:</label> <!--  -->
                    <input type="text" class="form-control" id="Fecha"  name="Fecha">
                </div>    
                
                <div class="mb-3">
                    <label for="Origen">Origen:</label> <!--  -->
                    <input type="text" class="form-control" id="Origen"  name="Origen">
                </div>     

                <div class="mb-3">
                    <label for="Destino">Destí:</label> <!-- D -->
                    <input type="text" class="form-control" id="Destino"  name="Destino">
                </div> 


                <div class="mb-3">
                    <label for="IdVuelo">Avió:</label> <!-- IdV -->
                    <input type="text" class="form-control" id="IdVuelo"  name="IdVuelo">
                </div>    

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
            <span>
                <?php if (isset($_GET['error'])){
                echo $_GET['error'];
                }
                ?>
            </span>
        </div>
    </body>
</html>