
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Vols</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    <body>
        <?php include "header.php"?>
        <div class="container mt-3">
            <h2>Avions</h2>
            <div class="float-end"><a href="../includes/generatePdf.php"><button class="btn btn-primary">Generate PDF</button></a> </div>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Identificador Avió</th>
                    <th>Matrícula</th>
                    <th>Fabricant</th>
                    <th>Model</th>
                    <th>Capacitat</th>
                    <th>Autonomia/Vol</th>
                </tr>
                <tr> Avions seleccionats:
                <?php
                include ("../includes/avions-inc.php");
                ?>
                    <?php if($avions!=0){?>
                        <?php foreach($avions as $avio): ?> <!-- LLISTA VOLS ACABAR..... -->
                            <tr>
                            <td><?= $avio["IdAvion"] ?></td> 
                            <td><?= $avio["Matricula"] ?></td>
                            <td><?= $avio["Fabricante"] ?></td>
                            <td><?= $avio["Modelo"] ?></td>
                            <td><?= $avio["Capacidad"] ?></td>
                            <td><?= $avio["AutonomiaVuelo"] ?></td>
                        </tr>
                        <?php endforeach ?>
                    <?php }?>
                </tr>
            </thead>
            </table>
        </div>
    </body>
</html>