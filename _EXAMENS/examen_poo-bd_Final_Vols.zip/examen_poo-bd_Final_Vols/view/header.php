<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <div class="container-fluid">

        <a class="navbar-brand" href="../index.php">Logo</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav  me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="signup.php">Registre</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="avions.php">Avions</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="nouavio.php">alta avio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="vols.php">Vols</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="nouvol.php">Alta vol</a>
                </li>
            </ul>
            <div class="d-flex">
                <ul class="navbar-nav  me-auto">
                    <li class="nav-item">
                        <a href="../index.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a href="../includes/logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>