
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Vuelos/Alta Nou Avió</title> <!-- NOU AVIÓ -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    <body>
        <?php include "header.php"?>
        <div class="container mt-3">
            <h2>Alta Nou Avió</h2>
            <form action="../includes/nouavio-inc.php" method="post"> 

       <!--     <div class="mb-3">
                    <label for="IdAvion">Identificador Avió:</label> 
                    <input type="text" class="form-control" id="IdAvion"  name="IdAvion">
                </div> -->

                <div class="mb-3">
                    <label for="Matricula">Matrícula:</label> <!-- MATRÍCULA -->
                    <input type="text" class="form-control" id="Matricula"  name="Matricula">
                </div>    
                
                <div class="mb-3">
                    <label for="Fabricante">Fabricant:</label> <!-- FABRICANTE -->
                    <input type="text" class="form-control" id="Fabricante"  name="Fabricante">
                </div>     

                <div class="mb-3">
                    <label for="Modelo">Model:</label> <!-- MODELO -->
                    <input type="text" class="form-control" id="Modelo"  name="Modelo">
                </div> 


                <div class="mb-3">
                    <label for="Capacidad">Capacitat:</label> <!-- Capacidad -->
                    <input type="text" class="form-control" id="Capacidad"  name="Capacidad">
                </div>    

                <div class="mb-3">
                    <label for="AutonomiaVuelo">Autonomia del Vol:</label> <!--  -->
                    <input type="text" class="form-control" id="AutonomiaVuelo"  name="AutonomiaVuelo">
                </div>  

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
            <span>
                <?php if (isset($_GET['error'])){
                echo $_GET['error'];
                }
                ?>
            </span>
        </div>
    </body>
</html>