<?php // CREAR NOU VOL

if($_SERVER["REQUEST_METHOD"] == "POST"){ //

    // recoger datos del formulario
   // $idAvion = $_POST["IdAvion"]; // id
    $idvuelo = $_POST["IdVuelo"]; // Ha de ser mateix Nom que a Formulari noupis.php!
    $fecha = $_POST["Fecha"];
    $origen = $_POST["Origen"];
    $destino = $_POST["Destino"];
    $idvol = $_POST["IdVol"];

    //instanciar las classes
    require "../model/connection.php";
    require "../model/avio.php"; // Depèn de avio.php - BD
    require "../controler/volContr.php"; // Depèn de ...Contr.php - Funcions

    $noupis = new avioContr($idAvion, $matricula, $fabricante, $modelo, $capacidad, $autonomiaVuelo); // Classe del Controler
    $noupis->nouAvio(); // nouPis és una Funció de la Classe avioContr

    //Volver a la pagina inicial (si està tot bé!)
    header("Location: ../view/avions.php"); // RESULTAT OK

}