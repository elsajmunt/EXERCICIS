<?php 

class reservaContr extends Reserva{ // Classe Reserva a la carpeta Model << afegir 
    private $id;
    private $data;


    private function __construct($id, $data){
        $this->id = $id;
        $this->data = $data;
    }

    /* Setters and getters */ 

    private function setid($id){ // ID RESERVA
        $this->id = $id;
    }
    private function getid(){
        return $this->id;
    }


    private function setdata($id){ // DATA RESERVA
        $this->data = $data;
    }
    private function getdata(){
        return $this->data;
    }


    /*** */
    
    // FUNCIONS PENDENTS ..... <<
            
} 

