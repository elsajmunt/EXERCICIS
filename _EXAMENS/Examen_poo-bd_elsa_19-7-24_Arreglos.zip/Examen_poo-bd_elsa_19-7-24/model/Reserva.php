<?php
class Reserva extends Connection{ // CONEXIONS A LA BASE DE DADES:

    protected function insertReserva($id, $tipus){ // AFEGIR DADES de la Reserva - INSERT
        $error = false;
        $stmt = $this->connect()->prepare("INSERT INTO reserves (id, tipus) VALUES (?,?)");

        if(!$stmt->execute(array($id, $tipus))){
            $error = true;
        }
        $stmt = null;
        return $error;
    }
    protected function selectReserva($tipus, $id){ // MOSTRAR DADES de la Reserva -SELECT
        $stmt = $this->connect()->prepare("SELECT tipus FROM reserves WHERE tipus = ? OR id = ?;"); //?..
        if(!$stmt->execute(array($tipus, $id))){
            $stmt = null;
            header("Location: .../view/noupis.php?error=stmtfailed"); // Error
            exit();
        }
        $resultCheck = false;
        if($stmt->rowCount()>0){
            $resultCheck = true;
        }
        return $resultCheck;
    }
}