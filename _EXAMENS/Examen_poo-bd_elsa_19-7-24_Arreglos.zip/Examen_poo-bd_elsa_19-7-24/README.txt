DADES PIS:

id 
tipus
numhabitacions
numlavabos

--
Identificador Pis:
Tipus:
	Venta
Num. habitacions:
Num. Lavabos: 

---------------
DADES USUARI: 

`users` 
  `users_id` 
  `users_uid` 
  `users_pwd` 
  `users_email` 